package com.jalasoft.practices.pattern;

import java.util.ArrayList;
import java.util.List;

/**
 * @author HP
 * @version 1.1
 */
public class StudentBuilder {
    private Student student;
    private List<String> courses;

    public StudentBuilder(int id, String name, String lastName) {
        this.student = new Student(id, name, lastName);
    }

    public StudentBuilder name(String name) {
        this.student.setName(name);
        return this;
    }

    public StudentBuilder lastName(String lastName) {
        this.student.setLastName(lastName);
        return this;
    }

    public StudentBuilder age(int age) {
        this.student.setAge(age);
        return this;
    }

    public StudentBuilder gender(String gender) {
        this.student.setGender(gender);
        return this;
    }

    public StudentBuilder courses(String course) {
        if (this.courses == null) {
            this.courses = new ArrayList<>();
            this.student.setCourses(this.courses);
        }
        this.courses.add(course);
        return this;
    }

    public Student build() {
        return this.student;
    }
}
