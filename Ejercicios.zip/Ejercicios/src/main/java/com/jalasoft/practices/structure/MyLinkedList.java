package com.jalasoft.practices.structure;

import java.util.Collection;
import java.util.function.Consumer;

/**
 * @author HP
 * @version 1.1
 */
public class MyLinkedList<T> {
    private Node first;
    private Node last;

    public  MyLinkedList() {
        first = null;
        last = null;
    }

    public void add(T data) {
        Node newNode = new Node(data);
        newNode.setNext(null);

        if(first == null) {
            first = newNode;
        } else {
            last.setNext(newNode);
        }
        last = newNode;
    }

    public void addLast(T data) {
        this.add(data);
    }

    public void addFirst(T data) {
        Node newNode = new Node(data);
        newNode.setNext(null);

        if(first == null) {
            first = newNode;
            last = newNode;
        } else {
            newNode.setNext(first);
            first = newNode;
        }
    }

    public void print() {
        Node node = first;
        while (node != null) {
            System.out.println(node.getData());
            node = node.getNext();
        }
    }

}
