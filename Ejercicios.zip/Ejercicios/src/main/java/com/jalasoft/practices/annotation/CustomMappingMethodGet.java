package com.jalasoft.practices.annotation;

import com.jalasoft.practices.generic.GenericValue;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @author HP
 * @version 1.1
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface CustomMappingMethodGet {
    String getPath() default "";
}
