package com.jalasoft.practices.interface1;

public interface ICalculador {
    int sumar(int a, int b);

    static Calculadora getInstance(int val) {
        return new Calculadora(val);
    }
}
