package com.jalasoft.practices.generic;

/**
 * @author HP
 * @version 1.1
 */
public class GenericValue<T> {

    private T val;

    public GenericValue(T val) {
        this.val = val;
    }

    public T getVal() {
        return val;
    }

    public void setVal(T val) {
        this.val = val;
    }
}
