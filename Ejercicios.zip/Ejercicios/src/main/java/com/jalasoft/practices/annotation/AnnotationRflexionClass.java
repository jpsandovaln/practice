package com.jalasoft.practices.annotation;

/**
 * @author HP
 * @version 1.1
 */

@CustomMappingClass(
        path = "/api/v2"
)
public class AnnotationRflexionClass {

    @CustomMappingMethodGet(getPath = "/getExtract")
    public void getValue() {
        System.out.println("get method");
    }

    @CustomMappingMethodPost(postPath = "/postExtract")
    public void postValue() {
        System.out.println("post method");
    }
}
