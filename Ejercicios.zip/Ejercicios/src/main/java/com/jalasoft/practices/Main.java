package com.jalasoft.practices;

import com.jalasoft.practices.annotation.AnnotationRflexionClass;
import com.jalasoft.practices.annotation.CustomMappingClass;
import com.jalasoft.practices.annotation.CustomMappingMethodGet;
import com.jalasoft.practices.annotation.CustomMappingMethodPost;
import com.jalasoft.practices.pattern.Student;
import com.jalasoft.practices.pattern.StudentBuilder;


import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        System.out.println("hello");

        Student student1 = new Student(1, "juan", "Perez");
        /*Student student2 = new Student(2, "Maria", "Vargas", 20);
        Student student3 = new Student(3, "Carlos", "Romero", 30, "M");*/

        List<String> courses = new ArrayList<>();
        courses.add("c1");
        courses.add("c2");
        courses.add("c3");

        /*Student student4 = new Student(4, "Tereza", "Lopez", 34, "F", courses);*/

        Student student5 = new StudentBuilder(5, "Manuel", "Vargas")
                .gender("M")
                .age(35)
                .age(68)
                .courses("c4")
                .courses("c5")
                .courses("c6")
                .courses("c7")
                .build();

        student5.getCourses().stream().forEach(value -> System.out.println(value));
    }
/*
    private static void testAnnotation() {
        System.out.println("test annotation");

        String classMappingPath = "";
        String getMethodMappingPath = "";
        String postMethodMappingPath = "";

        Class<AnnotationRflexionClass> annClass = AnnotationRflexionClass.class;


        if (annClass.isAnnotationPresent(CustomMappingClass.class)) {
            Annotation annotation = annClass.getAnnotation(CustomMappingClass.class);
            CustomMappingClass customClass = (CustomMappingClass) annotation;
            classMappingPath = customClass.path();
        }

        Method[] methods = annClass.getMethods();

        System.out.println("*********************************");
        for (Method method : methods) {
            System.out.println("-----------------------------");
            System.out.println(method.getName());
            System.out.println("-----------------------------");
            if (method.isAnnotationPresent(CustomMappingMethodGet.class)) {
                Annotation annotation = method.getAnnotation(CustomMappingMethodGet.class);
                CustomMappingMethodGet customClass = (CustomMappingMethodGet) annotation;
                getMethodMappingPath = customClass.getPath();
            }

            if (method.isAnnotationPresent(CustomMappingMethodPost.class)) {
                Annotation annotation = method.getAnnotation(CustomMappingMethodPost.class);
                CustomMappingMethodPost customClass = (CustomMappingMethodPost) annotation;
                postMethodMappingPath = customClass.postPath();
            }

        }
        System.out.println("*********************************");

        System.out.println(classMappingPath + getMethodMappingPath);
        System.out.println(classMappingPath + postMethodMappingPath);

    }*/
}