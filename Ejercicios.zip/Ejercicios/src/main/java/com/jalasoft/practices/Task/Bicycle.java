package com.jalasoft.practices.Task;

/**
 * @author HP
 * @version 1.1
 */
public class Bicycle extends Land {
    private boolean exercise;

    public Bicycle(String name, int price, boolean hasMotor, boolean exercise) {
        super(name, price, hasMotor);
        this.exercise = exercise;
    }

    public String displayData() {
        return super.displayData() + ", exercise = " + this.exercise;
    }
}
