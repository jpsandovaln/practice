package com.jalasoft.practices.Task;

/**
 * @author HP
 * @version 1.1
 */
public class Car extends Land {
    private boolean useGas;

    public Car(String name, int price, boolean hasMotor, boolean useGas) {
        super(name, price, hasMotor);
        this.useGas = useGas;
    }

    public String displayData() {
        return super.displayData() + ", useGas = " + this.useGas;
    }
}
