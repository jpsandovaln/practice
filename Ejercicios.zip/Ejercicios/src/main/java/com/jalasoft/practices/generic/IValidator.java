package com.jalasoft.practices.generic;

/**
 * @author HP
 * @version 1.1
 */
public interface IValidator<T> {
    boolean validate(T val);
}
