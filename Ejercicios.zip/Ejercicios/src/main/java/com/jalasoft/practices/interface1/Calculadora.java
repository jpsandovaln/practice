package com.jalasoft.practices.interface1;

/**
 * @author HP
 * @version 1.1
 */
class Calculadora implements ICalculador {

    public Calculadora(int val) {
        System.out.println(val);
    }

    public Calculadora() {
    }

    @Override
    public int sumar(int a, int b) {
        return a + b;
    }
}
