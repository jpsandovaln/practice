package com.jalasoft.practices.interface1;

/**
 * @author HP
 * @version 1.1
 */
public abstract class FactoryCalcular {

    public static  Calculadora getInstance(String flag) {
        if (flag.equals("text")) {
            return new Calculadora();
        }
        return null;
    }
}
