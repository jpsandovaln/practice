package com.jalasoft.practices.Task;

import java.util.ArrayList;
import java.util.List;

/**
 * @author HP
 * @version 1.1
 */
public class ListLandTransport {
    List<Land> landList = new ArrayList<>();

    public void addLand(Land land) {
        landList.add(land);
    }

    public void display() {
        landList.stream().forEach(land -> System.out.println(land.displayData()));
    }
}
