package com.jalasoft.practices.polymorphism;

/**
 * @author HP
 * @version 1.1
 */
public class Animal {
    String name;
    String color;

    public String getName() {
        return name;
    }

    public String getColor() {
        return color;
    }

    public Animal(String name, String color) {
        this.name = name;
        this.color = color;
    }

    public void desplazar() {
        System.out.println("caminando");
    }
}
