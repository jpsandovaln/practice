package com.jalasoft.practices.generic;

/**
 * @author HP
 * @version 1.1
 */
public class Validation<T> implements IValidator<T> {
    @Override
    public boolean validate(T val) {
        return val != null;
    }
}
